#!/bin/bash

	#	//	phpmyadmin-finder
	#	//	type		: <<scannerxxxxxx>>
	#	//	severity	: 
	#	//	tags		: <<missconfigsx>> <<phpmyadminxxxxx>>
	#	//	author		: RavenC4
	#	//	series		: IX
	#	//	description	: Find phpmyadmin with directory searching.
	#	//	reference	: https://github.com/projectdiscovery/nuclei-templates/blob/main/http/exposed-panels/phpmyadmin-panel.yaml

paths=(
	"/index.php"
	"/admin/login.php"
	"/pma/"
	"/pmd/"
    "/phpmyadmin/"
    "/admin/phpmyadmin/"
    "/_phpmyadmin/"
    "/administrator/components/com_joommyadmin/phpmyadmin/"
    "/apache-default/phpmyadmin/"
    "/blog/phpmyadmin/"
    "/forum/phpmyadmin/"
    "/php/phpmyadmin/"
    "/typo3/phpmyadmin/"
    "/web/phpmyadmin/"
    "/xampp/phpmyadmin/"
    "/phpMyAdmin/"
    "/phpma/"
    "/phpMyAdmin/index.php"
	)
for path in ${paths[@]}; do
	if [[ `curl --silent --max-time 5 "-kIs" "$select_domain_file$path" | grep -Ew "200 OK|HTTP/2 200|HTTP/1.1 200"` ]];
	then
		echo -e "$artemix_box$BLUE phpmyadmin-finder$GREEN $select_domain_file$path$NORM Found phpmyadmin path with 200 return"
	fi
done