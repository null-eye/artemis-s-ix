# Python program to Bypass CF
#
# Requirements:
# pip install argparse
# pip install cloudscraper

#	Example: https://gurukul.tslibrary.in/admin/login.php
#	https://millennialschoice.in/admin/login.php
#	https://pathfindershamli.in/admin/login.php

import argparse
import cloudscraper

# Initialize parser
parser = argparse.ArgumentParser()

# Adding optional argument
parser.add_argument("-u", "--url", help = "Show Output")

# Read arguments from command lineurl
args = parser.parse_args()
scraper = cloudscraper.create_scraper(delay=30)
html = scraper.get(args.url)
if args.url:
	# print(html.status_code)
	with open("response.html", "wb") as f:
	    f.write(html.content)